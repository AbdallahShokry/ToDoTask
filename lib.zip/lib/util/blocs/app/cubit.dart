import 'package:flutter/cupertino.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:to_do/util/blocs/app/states.dart';

class AppBloc extends Cubit<AppStates> {
  AppBloc() : super(AppInitialState());

  static AppBloc get(context) => BlocProvider.of<AppBloc>(context);

  late Database database;

  void initDatabase() async {
    var databasesPath = await getDatabasesPath();
    String path = p.join(databasesPath, 'to_do.db');

    debugPrint('AppDatabaseInitialized');

    openAppDatabase(
      path: path,
    );

    emit(AppDatabaseInitialized());
  }

  void openAppDatabase({
    required String path,
  }) async {
    openDatabase(
      path,
      version: 1,
      onCreate: (Database db, int version) async {
        await db.execute(
          'CREATE TABLE tasks (id INTEGER PRIMARY KEY, title TEXT , currentDate DATE , startTime TIME , endTime TIME )',
        );

        debugPrint('Table Created');
      },
      onOpen: (Database db) {
        debugPrint('AppDatabaseOpened');
        database = db;

        getTasksData();
      },
    );
  }

  TextEditingController titleController = TextEditingController();
  TextEditingController currentDateController = TextEditingController();
  TextEditingController startTimeController = TextEditingController();
  TextEditingController endTimeController = TextEditingController();
  TextEditingController remindController = TextEditingController();

  void insertTasksData() {

    database.transaction((txn) async {
      txn.rawInsert(
          'INSERT INTO tasks(title, currentDate, startTime, endTime ) VALUES("${titleController.text}", "${currentDateController.text}", "${startTimeController.text}", "${endTimeController.text}")');
    }).then((value) {
      debugPrint('User Data Inserted');

      getTasksData();

      emit(AppDatabaseTaskCreated());
    });
  }

  
  List<Map> tasks = [];

  void getTasksData() async {
    emit(AppDatabaseLoading());

    database.rawQuery('SELECT title FROM tasks ').then((value) {
      debugPrint('Users Data Fetched');
      tasks = value;
      debugPrint(tasks.toString());
      emit(AppDatabaseTasks());
    });
  }

  void del(){
    database.transaction((txn) async {
      txn.rawDelete('DELETE FROM tasks ').then((value) => emit(DeleteTasks()));

      });}
}